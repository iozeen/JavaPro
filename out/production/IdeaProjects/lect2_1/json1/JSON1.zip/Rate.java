package com.company;

public class Rate {
    public String id;
    public String Name;
    public double Rate;
    public String Date;
    public String Time;
    public String Ask;
    public String Bid;
}
