package com.company;

/**
 * Created by Bios on 07.02.2015.
 */
public class Address {
    String city;
    String country;

    public Address() {}
}
