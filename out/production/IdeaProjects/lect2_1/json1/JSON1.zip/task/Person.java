package com.company;

/**
 * Created by Bios on 07.02.2015.
 */
public class Person {
    String name;
    String surname;
    String[] phones;
    Address address;

    public Person() {}
}
