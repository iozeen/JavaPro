package com.company;

public class Query {
    public int count;
    public String created;
    public String lang;
    public Results results;
}
