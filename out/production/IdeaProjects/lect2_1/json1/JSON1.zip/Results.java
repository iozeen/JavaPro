package com.company;

public class Results {
    public Rate[] rate;
}
