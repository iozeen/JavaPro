package com.company;

public class JSON {
    public Query query;
}
